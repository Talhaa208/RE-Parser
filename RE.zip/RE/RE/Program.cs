﻿using System;

namespace RE
{
    class Program
    {
        static void Main(string[] args)
        {
            //(a+b)*a+(a+b)+b(a+b)*aa+bb(a)*
            Console.Write("Enter String which you want to match with the RE: ");
            // Input string
            string input = Console.ReadLine();

            // Initialize variables for matching
            int i = 0;
            int j = 0;

            // Loop through the input string
            while (i < input.Length)
            {
                // Check for (a+b)*a
                if (i < input.Length && (input[i] == 'a' || input[i] == 'b'))
                {
                    i++;
                    j++;
                    if (i < input.Length && input[i] == 'a')
                    {
                        i++;
                        j++;
                    }
                }
                // Check for (a+b)
               else if (i < input.Length && (input[i] == 'a' || input[i] == 'b'))
                {
                    i++;
                    j++;
                }
                // Check for b(a+b)*aa
                if (i < input.Length && input[i] == 'b')
                {
                    i++;
                    while (i < input.Length && (input[i] == 'a' || input[i] == 'b'))
                    {
                        i++;
                    }
                    if (i < input.Length && input[i] == 'a'&& input[i] == 'a')
                    {
                        i += 1;
                        j++;
                    }
                }

                //if (i < input.Length && input[i] == 'a' && input[i + 1] == 'a')
                //{
                //    i += 2;
                //    while (i < input.Length && input[i] == 'b')
                //    {
                //        i++;
                //    }
                //    if (i < input.Length && input[i] == 'a' && input[i + 1] == 'a')
                //    {
                //        i += 2;
                //        j++;
                //    }
                //}

                // Check for bb(a)*
                if (i < input.Length && input[i] == 'b' && input[i + 1] == 'b')
                {
                    i += 1;
                    while (i < input.Length && input[i] == 'a')
                    {
                        i++;
                    }
                    j++;
                }
            }

            // Check if all input matched
            if (i == input.Length && j > 0)
            {
                Console.WriteLine("Input matches the regular expression.");
            }
            else
            {
                Console.WriteLine("Input does not match the regular expression.");
            }
        }
    }
}